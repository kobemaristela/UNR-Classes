public class BlueSpruce extends Tree {

    public BlueSpruce() {
        description = "Colorado Blue Spruce";
    }

    public int cost() {
        return 20;
    }
}