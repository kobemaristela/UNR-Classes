public abstract class Decoration extends Tree {
    Tree myTree;
    public abstract String getDescription();
}