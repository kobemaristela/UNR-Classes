public class DouglasFir extends Tree {

    public DouglasFir() {
        description = "Douglas Fir";
    }

    public int cost() {
        return 15;
    }
}