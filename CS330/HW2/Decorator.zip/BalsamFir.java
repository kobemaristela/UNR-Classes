public class BalsamFir extends Tree {

    public BalsamFir() {
        description = "Balsam Fir";
    }

    public int cost() {
        return 5;
    }
}