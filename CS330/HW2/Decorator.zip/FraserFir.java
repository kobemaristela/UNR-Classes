public class FraserFir extends Tree {

    public FraserFir() {
        description = "Fraser Fir";
    }

    public int cost() {
        return 12;
    }
}