public interface Command {
    public void orderUp();
}