public class ShortOrderCook {

    public ShortOrderCook () {}

    public void makeBurger () {
        System.out.println("Making burger...");
    }

    public void makeShake() {
        System.out.println("Making shake...");
    }
}